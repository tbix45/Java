package com.tb.pokebook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokeBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
