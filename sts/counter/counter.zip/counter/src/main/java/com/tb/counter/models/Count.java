package com.tb.counter.models;

public class Count {

}
